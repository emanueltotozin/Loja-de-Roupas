
package Model;
public class UsuarioM {
private String nome ;
private String email ;
private String cpf ;
private String datan ;
private String telefone ;

    public UsuarioM() {
    }

    public UsuarioM(String nome, String email, String cpf, String datan, String telefone) {
        this.nome = nome;
        this.email = email;
        this.cpf = cpf;
        this.datan = datan;
        this.telefone = telefone;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getCpf() {
        return cpf;
    }

    public void setCpf(String cpf) {
        this.cpf = cpf;
    }

    public String getDatan() {
        return datan;
    }

    public void setDatan(String datan) {
        this.datan = datan;
    }

    public String getTelefone() {
        return telefone;
    }

    public void setTelefone(String telefone) {
        this.telefone = telefone;
    }
}

