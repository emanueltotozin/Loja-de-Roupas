package DAO;
import Model.UsuarioM;
import Conexao.conexao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import java.util.List;
import java.util.ArrayList;

public class UsuarioDAO {
    public void inserirUsuario(UsuarioM a)
    {
        try{
        String SQL="INSERT INTO emanuel_roupas.cliente (nome, email, cpf, datan, telefone) VALUES (?,?,?,?,?)"; 
        Connection minhaConexao = conexao.getConexao();
        PreparedStatement comando = minhaConexao.prepareStatement(SQL);
        comando.setString(1, a.getNome());
        comando.setString(2, a.getEmail());
        comando.setString(3, a.getCpf());
        comando.setString(4, a.getDatan());
        comando.setString(5, a.getTelefone());
        int retorno = comando.executeUpdate();
        if(retorno>0)
        {
            JOptionPane.showMessageDialog(null, "Usuario: "+a.getNome()+" Cadastrado com Sucesso!!");
        }
        else
        {
            JOptionPane.showMessageDialog(null, "Erro ao cadastrar Usuario: "+a.getNome()+" Verifique os Logs");
        }
        }
        catch(SQLException ex)
        {
            Logger.getLogger(UsuarioDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
        public List <UsuarioM> listaDeUsuarios(){
        try {
            String SQL="SELECT nome, email, cpf, datan, telefone FROM emanuel_roupas.cliente";
            List <UsuarioM>listaDeUsuarios=new ArrayList<UsuarioM>();
            Connection c =conexao.getConexao();
            PreparedStatement ps=c.prepareStatement(SQL);
            ResultSet resultado = ps.executeQuery();
            while(resultado.next()){
                UsuarioM atual = new UsuarioM();
                atual = this.pegaDados(resultado);
                listaDeUsuarios.add(atual);
            }
           
            return listaDeUsuarios;
        } catch (SQLException ex) {
            Logger.getLogger(UsuarioDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
        return null;
    }
   
   
    private UsuarioM pegaDados(ResultSet resultado){
        try {
            UsuarioM atual=new UsuarioM();
            atual.setNome(resultado.getString("nome"));
            atual.setEmail(resultado.getString("email"));
            atual.setCpf(resultado.getString("cpf"));
            atual.setDatan(resultado.getString("datan"));
            atual.setTelefone(resultado.getString("telefone"));
            return atual;
        } catch (SQLException ex) {
            Logger.getLogger(UsuarioDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
        return null;
    } 
       
}
